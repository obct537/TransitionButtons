.. contents::

Introduction
============

The TransitionButtons add-on is a simple plugin for the Plone platform 
to make the state-change buttons in the edit bar more visibile. 
It just adds a small portlet-like box with 
very obvious buttons to publish/retract/etc the current document, assuming
the user has rights to do so. 